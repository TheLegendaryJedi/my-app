import styled from "styled-components";

const AboutContainer = styled.div`
    margin: 1rem 5rem 0 5rem;
`

export { AboutContainer };