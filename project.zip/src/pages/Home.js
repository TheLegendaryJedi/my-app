import React from 'react'
import { HomeContainer } from './Home.style'

export const Home = () => {
  return (
    <HomeContainer>
      <h1>Home</h1>
      <hr/>
    </HomeContainer>
  )
}
