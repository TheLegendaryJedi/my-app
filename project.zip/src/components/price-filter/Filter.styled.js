import styled from 'styled-components';

// const FilterMenuContainer = styled.div`
//     display: flex;
//     flex-direction: row;
// `;

// export { FilterMenuContainer };
