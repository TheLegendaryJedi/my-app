import styled from "styled-components";

const ProductWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin: 0 10rem;
`;
export { ProductWrapper };
