import React from 'react'
import { TopMenu } from '../top-menu/TopMenu'

export const Header = () => {
  return (
    <>
      <TopMenu/>
    </>
  )
}
