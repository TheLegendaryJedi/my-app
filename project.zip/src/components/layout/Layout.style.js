import styled from "styled-components";

const LayoutContainer = styled.div`
    margin-bottom: 5rem;
`;

export { LayoutContainer };